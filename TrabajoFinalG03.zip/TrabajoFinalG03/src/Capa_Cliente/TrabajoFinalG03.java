package Capa_Cliente;

public class TrabajoFinalG03 {

    public static void main(String[] args) {
        FrmMenuPrincipal menu = new FrmMenuPrincipal();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
    }
    
}

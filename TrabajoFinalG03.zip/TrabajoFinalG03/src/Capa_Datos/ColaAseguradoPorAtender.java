package Capa_Datos;

import TColas.TColaEn;

/*Para gestionar los asegurados ya atendidos*/

public class ColaAseguradoPorAtender {
    private static TColaEn ColaPorAtender = new TColaEn();
    
    public static TColaEn consultar(){
        return ColaPorAtender;
    }
    
    public static void añadir(Object objAsegurado){
        ColaPorAtender.Insertar(objAsegurado);
    }
    
    public static Object eliminar(){
        return ColaPorAtender.Eliminar();
    }
}

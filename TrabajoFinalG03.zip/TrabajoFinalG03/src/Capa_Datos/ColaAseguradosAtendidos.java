package Capa_Datos;

import TColas.TColaEn;

/*Para sacar una cita medica se debe sacar un ticket de atencion
y deben pasar por una cola para generar la cita medica*/

public class ColaAseguradosAtendidos {
    private static TColaEn ColaAseguradosAtendidos = new TColaEn();
    
    public static TColaEn consultar(){
        return ColaAseguradosAtendidos;
    }
    
    public static void añadir(Object objAsegurado){
        ColaAseguradosAtendidos.Insertar(objAsegurado);
    }
    
    public static Object eliminar() {
        return ColaAseguradosAtendidos.Eliminar();
    }
}

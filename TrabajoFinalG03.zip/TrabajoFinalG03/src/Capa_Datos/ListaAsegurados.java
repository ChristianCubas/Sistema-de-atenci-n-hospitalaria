package Capa_Datos;

import TListas.TListaEn;

public class ListaAsegurados {
    private static TListaEn lista_asegurados = new TListaEn();
    
    public static TListaEn consultar(){
        return lista_asegurados;
    }
    
    public static void añadir(Object objaseg){
        lista_asegurados.Adicionar(objaseg);
    }

}

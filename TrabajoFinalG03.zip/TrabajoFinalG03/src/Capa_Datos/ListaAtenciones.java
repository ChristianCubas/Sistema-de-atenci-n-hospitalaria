package Capa_Datos;

import TListas.TListaEn;

/*A esta lista de atenciones se le conoce con el nombre de
Historia medica*/

public class ListaAtenciones {
    private static TListaEn listaAtenciones = new TListaEn();
    
    public static TListaEn consultar(){
        return listaAtenciones;
    }
    
    public static void añadir(Object objAtencion){
        listaAtenciones.Adicionar(objAtencion);
    }
}

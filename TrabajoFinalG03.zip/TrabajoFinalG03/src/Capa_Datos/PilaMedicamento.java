package Capa_Datos;

import TPilas.TPilaEn;

public class PilaMedicamento {
    private static TPilaEn pilaMedicamento = new TPilaEn();
    
    public static TPilaEn consultar(){
        return pilaMedicamento;
    }
    
    public static void añadir(Object objMedicamento){
        pilaMedicamento.Push(objMedicamento);
    }
    
    public static Object eliminar(){
        return pilaMedicamento.Pop();
    }
}

package Capa_Negocio;

import Capa_Datos.ColaAseguradoPorAtender;
import Capa_Datos.ListaAsegurados;
import TColas.TColaEn;
import TListas.TListaEn;
import java.util.Date;

public class Asegurado {
    private String dni;
    private String nombre;
    private int edad;
    private String telefono;
    String direccion;
    private Date fecha_nacimiento;
    private String sexo;

    public Asegurado(String dni, String nombre, int edad, String telefono, String direccion, Date fecha_nacimiento, String sexo) {
        this.dni = dni;
        this.nombre = nombre;
        this.edad = edad;
        this.telefono = telefono;
        this.direccion = direccion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.sexo = sexo;
    }
    
    public String getDireccion() {
        return direccion;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(Date fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public static TColaEn consultar(){
        return ColaAseguradoPorAtender.consultar();
    }
    
    public static void añadir(Object objAsegurado){
        ColaAseguradoPorAtender.añadir(objAsegurado);
    }
    
    public static TListaEn consultarLista(){
        return ListaAsegurados.consultar();
    }
    
    public static void añadirLista(Object objasegurado){
        ListaAsegurados.añadir(objasegurado);
    }
    
}

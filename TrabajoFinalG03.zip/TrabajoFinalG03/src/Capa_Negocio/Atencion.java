package Capa_Negocio;

import Capa_Datos.ColaAseguradosAtendidos;
import Capa_Datos.ListaAtenciones;
import TColas.TColaEn;
import TListas.TListaEn;
import java.util.Date;

public class Atencion {
    private String NroHistoria;//es alfanumerico
    private String dni; //Dato que me permitira relacionar asegurado con asegurado
    private float peso;
    private float talla;
    private float presion;
    private int  pulso;
    private float saturacion;
    private float temperatura;
    private float frecuencia_cardiaca;
    private String especialidad;
    private Date fecha;

    public Atencion(String NroHistoria, String dni, float peso, float talla, float presion, int pulso, float saturacion, float temperatura, float frecuencia_cardiaca, String especialidad, Date fecha) {
        this.NroHistoria = NroHistoria;
        this.dni = dni;
        this.peso = peso;
        this.talla = talla;
        this.presion = presion;
        this.pulso = pulso;
        this.saturacion = saturacion;
        this.temperatura = temperatura;
        this.frecuencia_cardiaca = frecuencia_cardiaca;
        this.especialidad = especialidad;
        this.fecha = fecha;
    }

    public String getNroHistoria() {
        return NroHistoria;
    }

    public void setNroHistoria(String NroHistoria) {
        this.NroHistoria = NroHistoria;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getTalla() {
        return talla;
    }

    public void setTalla(float talla) {
        this.talla = talla;
    }

    public float getPresion() {
        return presion;
    }

    public void setPresion(float presion) {
        this.presion = presion;
    }

    public int getPulso() {
        return pulso;
    }

    public void setPulso(int pulso) {
        this.pulso = pulso;
    }

    public float getSaturacion() {
        return saturacion;
    }

    public void setSaturacion(float saturacion) {
        this.saturacion = saturacion;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public float getFrecuencia_cardiaca() {
        return frecuencia_cardiaca;
    }

    public void setFrecuencia_cardiaca(float frecuencia_cardiaca) {
        this.frecuencia_cardiaca = frecuencia_cardiaca;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    public static TColaEn consultarAtendidos(){
        return ColaAseguradosAtendidos.consultar();
    }
    
    public static void añadirAtendidos(Object objAsegurado){
        ColaAseguradosAtendidos.añadir(objAsegurado);
    }

    public static TListaEn consultar(){
        return ListaAtenciones.consultar();
    }
    
    public static void añadir(Object objAtencion){
        ListaAtenciones.añadir(objAtencion);
    }
    
    public static Object datosDeUnPaciente(String dni){
        TColaEn colaAsegurados = Asegurado.consultar();
        
        for (int i = 0; i < colaAsegurados.Cantidad(); i++) {
            Asegurado asegurado = (Asegurado) colaAsegurados.Obtener(i);
            if (asegurado.getDni().equalsIgnoreCase(dni)) {
                return asegurado;
            }
        }
        
        return null;
    }
    
    public static TListaEn buscarAtencionesDeUnPaciente(String DNI){
        TListaEn AtencionesGeneral = Atencion.consultar();
        TListaEn AtencionesDeUnPaciente = new TListaEn();
        
        for (int i = 0; i < AtencionesGeneral.Cantidad(); i++) {
            Atencion atencion = (Atencion) AtencionesGeneral.Obtener(i);
            if (atencion.getDni().equalsIgnoreCase(DNI)) {
                AtencionesDeUnPaciente.Adicionar(atencion);
            }
        }
        
        return AtencionesDeUnPaciente;
    }
    
    public static int[] cantidadesEspecialidad(){
        TListaEn lista_atenciones = Atencion.consultar();
        int cantidades[] = new int[8];
        
        for (int i = 0; i < lista_atenciones.Cantidad(); i++) {
            Atencion atencion = (Atencion) lista_atenciones.Obtener(i);
            switch (atencion.getEspecialidad()) {
                case "Medicina general":
                    cantidades[0]++;
                    break;
                case "Otorrinologia":
                    cantidades[1]++;
                    break;
                case "Ginecologia":
                    cantidades[2]++;
                    break;
                case "Odontologia":
                    cantidades[3]++;
                    break;
                case "Psicologia":
                    cantidades[4]++;
                    break;
                case "Endocrinologia":
                    cantidades[5]++;
                    break;
                case "Urologia":
                    cantidades[6]++;
                    break;
                case "Cirugia":
                    cantidades[7]++;
                    break;
            }
        }
        
        return cantidades;
    }
    
    public static int[] cantxGenero(){
        TColaEn cola_porAtender = Asegurado.consultar();
        TColaEn cola_atendidos = Atencion.consultarAtendidos();
        int cantidad[] = new int[2];
        
        for (int i = 0; i < cola_porAtender.Cantidad(); i++) {
            Asegurado asegurado = (Asegurado) cola_porAtender.Obtener(i);
            if (asegurado.getSexo().equalsIgnoreCase("masculino")) {
                cantidad[0]++;
            }else{
                cantidad[1]++;
            }
        }
        
        for (int i = 0; i < cola_atendidos.Cantidad(); i++) {
            Asegurado aseg = (Asegurado) cola_atendidos.Obtener(i);
            if (aseg.getSexo().equalsIgnoreCase("masculino")) {
                cantidad[0]++;
            }else{
                cantidad[1]++;
            }
        }
        
        return cantidad;
    }
    
    public static Float[] porcentajexGenero(){
        TColaEn cola_porAtender = Asegurado.consultar();
        TColaEn cola_atendidos = Atencion.consultarAtendidos();
        Float porcentajes[] = new Float[2];
        int cantidadesxgenero[] = new int[2];
        
        cantidadesxgenero[0] = Atencion.cantxGenero()[0];
        cantidadesxgenero[1] = Atencion.cantxGenero()[1];
        
        int totalPacientes = cola_porAtender.Cantidad() + cola_atendidos.Cantidad();
    
        porcentajes[0] = (float) cantidadesxgenero[0] / totalPacientes;
        porcentajes[1] = (float) cantidadesxgenero[1] / totalPacientes;
    
        return porcentajes;
    }
    
    
    public static int[] cantidadAtencionesPacientexEspecialidad(String dni){
        TListaEn lista_atenciones_de_un_paciente = buscarAtencionesDeUnPaciente(dni);
        int ctnAtenciones[] = new int[8];
        
        for (int i = 0; i < lista_atenciones_de_un_paciente.Cantidad(); i++) {
            Atencion atencion = (Atencion) lista_atenciones_de_un_paciente.Obtener(i);
            switch (atencion.getEspecialidad()) {
                case "Medicina general":
                    ctnAtenciones[0]++;
                    break;
                case "Otorrinologia":
                    ctnAtenciones[1]++;
                    break;
                case "Ginecologia":
                    ctnAtenciones[2]++;
                    break;
                case "Odontologia":
                    ctnAtenciones[3]++;
                    break;
                case "Psicologia":
                    ctnAtenciones[4]++;
                    break;
                case "Endocrinologia":
                    ctnAtenciones[5]++;
                    break;
                case "Urologia":
                    ctnAtenciones[6]++;
                    break;
                case "Cirugia":
                    ctnAtenciones[7]++;
                    break;
            }
        }
        
        return ctnAtenciones;
    }
    
}

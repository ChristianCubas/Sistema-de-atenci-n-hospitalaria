package Capa_Negocio;

import Capa_Datos.PilaMedicamento;
import TPilas.TPilaEn;
import java.util.Date;

public class Medicamento {
    private String nombre;
    private Date fecha_vencimiento;
    private boolean fotosensible;
    private String via_adminision;

    public Medicamento(String nombre, Date fecha_vencimiento, boolean fotosensible, String via_adminision) {
        this.nombre = nombre;
        this.fecha_vencimiento = fecha_vencimiento;
        this.fotosensible = fotosensible;
        this.via_adminision = via_adminision;
    }

    public String getVia_adminision() {
        return via_adminision;
    }

    public void setVia_adminision(String via_adminision) {
        this.via_adminision = via_adminision;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha_vencimiento() {
        return fecha_vencimiento;
    }

    public void setFecha_vencimiento(Date fecha_vencimiento) {
        this.fecha_vencimiento = fecha_vencimiento;
    }

    public boolean isFotosensible() {
        return fotosensible;
    }

    public void setFotosensible(boolean fotosensible) {
        this.fotosensible = fotosensible;
    }
    
    public static TPilaEn consultar(){
        return PilaMedicamento.consultar();
    }
    
    public static void añadir(Object objMedicamento) {
        PilaMedicamento.añadir(objMedicamento);
    }
    
    public static Object eliminar(){
        return PilaMedicamento.eliminar();
    }
    
    /*En un inicio pense en mostrar el ingreso de medicamentos
    clasificados pero debido a la cant de medicamentos no se pud :(*/
    
    public static TPilaEn[] clasificarMedicamentos(){
        //Pila original
        TPilaEn pila = Medicamento.consultar();
        //Creo pilas de filtro
        TPilaEn Paracetamol = new TPilaEn();
        TPilaEn Ibuprofeno = new TPilaEn();
        TPilaEn Tramadol = new TPilaEn();
        TPilaEn Morfina = new TPilaEn();
        TPilaEn Amoxicilina = new TPilaEn();
        TPilaEn Cefalexina = new TPilaEn();
        TPilaEn Heparina = new TPilaEn();
        TPilaEn Fluoxetina = new TPilaEn();
        TPilaEn Diclofenaco = new TPilaEn();
        TPilaEn Naproxeno = new TPilaEn();
        TPilaEn Acetaminofén = new TPilaEn();
        TPilaEn Alcohol = new TPilaEn();
        TPilaEn Insulina = new TPilaEn();
        TPilaEn Metformina = new TPilaEn();
        TPilaEn Gasas = new TPilaEn();
        TPilaEn Tegader = new TPilaEn();
        TPilaEn Suero = new TPilaEn();   
        
        int tamaño = pila.Cantidad();
        
        for (int i = 0; i < tamaño; i++) {
            Medicamento medicamento = (Medicamento) pila.Pop();
            switch (medicamento.getNombre()) {
                case "Paracetamol":
                    Paracetamol.Push(medicamento);
                    break;
                case "Ibuprofeno":
                    Ibuprofeno.Push(medicamento);
                case "Tramadol":
                    Tramadol.Push(medicamento);
                case "Morfina":
                    Morfina.Push(medicamento);
                case "Amoxicilina":
                    Amoxicilina.Push(medicamento);
                case "Cefalexina":
                    Cefalexina.Push(medicamento);
                case "Heparina":
                    Heparina.Push(medicamento);
                case "Fluoxetina":
                    Fluoxetina.Push(medicamento);
                case "Diclofenaco":
                    Diclofenaco.Push(medicamento);
                case "Naproxeno":
                    Naproxeno.Push(medicamento);
                case "Acetaminofén":
                    Acetaminofén.Push(medicamento);
                case "Alcohol":
                    Alcohol.Push(medicamento);
                case "Insulina":
                    Insulina.Push(medicamento);
                case "Metformina":
                    Metformina.Push(medicamento);
                case "Gasas":
                    Gasas.Push(medicamento);
                case "Tegader":
                    Tegader.Push(medicamento);
                case "Suero":
                    Suero.Push(medicamento);
                default:
                    throw new AssertionError();
            }
        }
        
        TPilaEn pila_final[] = new TPilaEn[17];
        pila_final[0]=Paracetamol;
        pila_final[1]=Ibuprofeno;
        pila_final[2]=Tramadol;
        pila_final[3]=Morfina;
        pila_final[4]=Amoxicilina;
        pila_final[5]=Cefalexina;
        pila_final[6]=Heparina;
        pila_final[7]=Fluoxetina;
        pila_final[8]=Diclofenaco;
        pila_final[9]=Naproxeno;
        pila_final[10]=Acetaminofén;
        pila_final[11]=Alcohol;
        pila_final[12]=Insulina;
        pila_final[13]=Metformina;
        pila_final[14]=Gasas;
        pila_final[15]=Tegader;
        pila_final[16]=Suero;
        
        return pila_final;
    }
    
    //Cantidad de medicamentos
    public static int[] cantMedicamentos(){
        TPilaEn pila = Medicamento.consultar();
        int cantidades[] = new int[17];
        
        int tamaño = pila.Cantidad();
        
        for (int i = 0; i < tamaño; i++) {
            Medicamento medicamento = (Medicamento) pila.Pop();
            switch (medicamento.getNombre()) {
                case "Paracetamol"->cantidades[0]++;
                case "Ibuprofeno"->cantidades[1]++;
                case "Tramadol"->cantidades[2]++;
                case "Morfina"->cantidades[3]++;
                case "Amoxicilina"->cantidades[4]++;
                case "Cefalexina"->cantidades[5]++;
                case "Heparina"->cantidades[6]++;
                case "Fluoxetina"->cantidades[7]++;
                case "Diclofenaco"->cantidades[8]++;
                case "Naproxeno"->cantidades[9]++;
                case "Acetaminofén"->cantidades[10]++;
                case "Alcohol"->cantidades[11]++;
                case "Insulina"->cantidades[12]++;
                case "Metformina"->cantidades[13]++;
                case "Gasas"->cantidades[14]++;
                case "Tegader"->cantidades[15]++;
                case "Suero"->cantidades[16]++;
            }
        }
        
        return cantidades;
    }
}
